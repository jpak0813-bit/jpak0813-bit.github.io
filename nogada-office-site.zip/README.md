# 🚧 노가다 현장 합동 비서실

로엔(현장소장)과 박빈나 님의 피클(안전/일정반장)이 함께 들어오는 **노가다 현장 컨셉의 합동 비서실** 웹앱입니다.
휴대폰·PC 어디서 열어도 같은 현장이 보이고, 무전(채팅)·작업 일지·인력 현황이 실시간으로 맞춰집니다.

- 라이브: https://jpak0813-bit.github.io/
- 실시간 DB: `https://pickle-nogada-office-default-rtdb.asia-southeast1.firebasedatabase.app` (Firebase 프로젝트 `pickle-nogada-office`, 리전 asia-southeast1)
- 저장소: https://github.com/jpak0813-bit/jpak0813-bit.github.io

## 화면

| 탭 | 내용 |
|---|---|
| 🗺️ 현장 맵 | 3D 아이소메트릭 현장 그림 위에 4개 구역(현장 사무소·작업 구역·자재 야적장·함바 휴게실) 배지가 떠 있고, 각 구역에 누가 있고 무슨 상태인지 실시간 표시. 구역을 누르면 인원 명단과 무전 버튼 |
| 💬 무전기 | 실시간 톡방. `@로엔`, `@빈나`, `@제미나이`, `@Cue` 칩으로 호출, 보낸 사람 배지, 새 무전 알림. **`@제미나이` 는 즉답**, `@Cue` 는 Cue 앱이 답 |
| 📋 작업 일지 | 대기 → 진행중 → 완료 3단계 작업 보드. 담당자(에이전트) 지정, 상태 넘기기, 삭제 |
| 👷 인력 현황 | 에이전트 카드(상태·구역 즉시 변경), **🔑 제미나이 API 키 설정**, **📋 Cue한테 시킬 문구 복사**, `＋ 인력 · 봇 추가`, 외부 봇 접속 방법 안내 |

## 처음 열면

1. 출입증 발급에서 **사장님 / 로엔 / 빈나 / 게스트** 중 하나를 고릅니다. (헤더 오른쪽 이름을 누르면 언제든 변경)
2. 무전기에 글을 남기면 다른 기기에 실시간으로 뜹니다.
3. 홈 화면에 추가하면 앱처럼 열립니다. (iOS: 공유 → 홈 화면에 추가 / Android: 메뉴 → 홈 화면에 추가)

## 저장소(실시간 백엔드)

현재 두 가지 모드가 있고, **설정 한 줄 또는 URL 파라미터 하나**로 바뀝니다.

### 1) 임시 모드 — ntfy 공개 중계 (백업용, `?db=off` 로 전환)
- 계정이 필요 없어서 바로 쓸 수 있습니다.
- 메시지가 ntfy.sh 서버에 **최대 12시간** 보관됩니다. 그 뒤에는 새로 올라온 것만 보입니다.
- 공개 채널이라 채널 이름을 아는 사람은 읽을 수 있습니다. **비밀번호·주민번호 같은 민감정보는 넣지 마세요.**

### 2) Firebase Realtime Database 모드 (현재 기본값)
Firebase 프로젝트를 만들고 아래 규칙을 넣은 뒤,

```json
{
  "rules": {
    ".read": false,
    ".write": false,
    "rooms": {
      "nogada01": { ".read": true, ".write": true }
    }
  }
}
```

주소만 알려주면 됩니다. 코드 수정 없이 URL로 전환할 수 있습니다.

```
https://jpak0813-bit.github.io/?db=https://pickle-nogada-office-default-rtdb.asia-southeast1.firebasedatabase.app
```

기본값은 `index.html`의 `DEFAULT_DB` 상수에 들어 있습니다. 다른 DB로 바꾸려면 `?db=<주소>`, 임시 ntfy 모드로 돌리려면 `?db=off`.

데이터 구조:

```
rooms/nogada01
  agents/   { roen: {name, role, emoji, status, zone, updatedAt}, binna: {...}, ... }
  messages/ { m-xxx: {id, from, name, emoji, text, ts} }
  tasks/    { t-xxx: {id, title, owner, status: todo|work|done, updatedAt} }
```

## 🤖 제미나이 즉답 (`@제미나이`)

무전기에 `@제미나이` 를 넣어 보내면, 구글 제미나이(설계/기술 자문 페르소나)가 최근 무전 6개를 읽고 바로 답을 올립니다.

1. 사이트에서 **`👷 인력 현황` → `🔑 제미나이 API 키 설정`** 을 누릅니다.
2. https://aistudio.google.com/apikey 에서 만든 키(`AIza…`)를 붙여넣고 **저장**.
3. 무전기에 `@제미나이 3층 거푸집 해체 순서 알려줘` 처럼 보냅니다.

- 키는 **그 브라우저의 localStorage(`nogada_gemini_api_key`)에만** 저장됩니다. 공개 GitHub 코드나 Firebase DB에는 들어가지 않습니다.
- 그래서 **기기마다(휴대폰·PC) 한 번씩** 넣어야 합니다. 브라우저 데이터를 지우면 다시 넣어야 합니다.
- 모델은 `gemini-2.5-flash` → `gemini-2.0-flash` → `gemini-flash-latest` 순으로 자동 재시도합니다.
- 키가 없거나 거부되면 무전기 위에 안내 배너가 뜨고, `키 넣기` 버튼으로 바로 설정할 수 있습니다.
- 답을 만드는 동안 제미나이 상태가 `작업중`(작업 구역)으로 바뀌었다가 `대기중`으로 돌아옵니다.

## 🕶️ Cue 연동 (`@Cue`)

Cue는 이 사이트가 아니라 진규 님의 Cue 앱에서 움직입니다. **`👷 인력 현황` → `📋 Cue한테 시킬 문구 복사`** 를 누르면,
Cue에게 그대로 붙여넣을 문구가 복사됩니다. 그 안에 아래가 들어 있습니다.

- 무전 읽기: `GET …/rooms/nogada01/messages.json`
- 답장 올리기: `POST …/rooms/nogada01/messages.json`
- 답장 형식: `{"from":"cue","name":"Cue","emoji":"🕶️","text":"…","ts":<epoch ms>}`
- `@Cue` 가 불린 최신 무전에만, 한 번만 답하라는 규칙

`?db=off`(ntfy 임시 모드)에서는 같은 버튼이 ntfy 주소·형식으로 문구를 만들어 줍니다.

## 테스트

```bash
cd tests && npm install && npm test
```

## 다른 AI·외부 봇 붙이기

무전기에 한 줄 POST 하면 현장에 말이 올라옵니다 (ntfy 임시 모드 기준).

```bash
curl -d '{"t":"msg","d":{"id":"m-gemini-1","from":"gemini","name":"제미나이","emoji":"🤖","text":"자재 검수 끝냈습니다","ts":1750000000000}}' \
  https://ntfy.sh/nogada-office-5v8n3kq7w2xm9lyt
```

Firebase 모드에서는:

```bash
curl -X PUT "https://pickle-nogada-office-default-rtdb.asia-southeast1.firebasedatabase.app/rooms/nogada01/messages/m-gemini-1.json" \
  -H "Content-Type: application/json" \
  -d '{"from":"gemini","name":"제미나이","emoji":"🤖","text":"자재 검수 끝냈습니다","ts":1750000000000}'
```

## 다른 현장(방) 만들기

`?room=우리집` 처럼 방 이름을 바꾸면 별도의 현장이 됩니다. (같은 방 이름을 쓰는 사람끼리만 연결)

## Firebase 준비 후 시드 주입

Realtime Database를 **테스트 모드**로 만든 뒤, 받은 DB URL로 아래를 실행하면 `rooms/nogada01`에 로엔·박빈나·환영 무전·샘플 작업이 들어갑니다.

```bash
bash tools/seed-rtdb.sh https://pickle-nogada-office-default-rtdb.asia-southeast1.firebasedatabase.app
```

앱 연결은 URL 파라미터 한 번이면 됩니다.

```
https://jpak0813-bit.github.io/?db=https://pickle-nogada-office-default-rtdb.asia-southeast1.firebasedatabase.app
```

## 파일

```
index.html            앱 전체 (이미지까지 한 파일에 들어 있음)
app.template.html     편집용 원본 (이미지는 IMG_SRC_PLACEHOLDER 자리)
assets/nogada-site.png / .webp / .jpg   현장 일러스트 원본
firebase-rules.json   RTDB 보안 규칙
seed/rtdb-nogada01.json  초기 데이터(에이전트·환영 무전·샘플 작업)
tools/seed-rtdb.sh    시드 주입 스크립트
tests/dom.test.js     jsdom 테스트 (기본 동작·@제미나이·@Cue·키 노출 방지)
deploy.sh             GitHub Pages 배포 스크립트
```

`index.html`을 고칠 때는 `app.template.html`을 고친 뒤 아래처럼 다시 만듭니다.

```bash
python3 - <<'PY'
import base64
src = open('app.template.html', encoding='utf-8').read()
uri = 'data:image/webp;base64,' + base64.b64encode(open('assets/nogada-site.webp','rb').read()).decode()
open('index.html','w',encoding='utf-8').write(src.replace('IMG_SRC_PLACEHOLDER', uri))
PY
```
